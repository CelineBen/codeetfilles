# Du code et des filles

## Les bases du CSS pour les débutants

Un workshop de 3 heures pour les filles de 11 à 18 ans.

- CSS pour débutantes (3hrs): [ici](https://celineben.github.io/codeetfilles/ge-css-fundamentals-FR-3hrs/cours.html)

Cette présentation est sous la license <a rel="license" href="http://creativecommons.org/licenses/by-nc/4.0/">Creative Commons Attribution-NonCommercial 4.0 International License</a>.
